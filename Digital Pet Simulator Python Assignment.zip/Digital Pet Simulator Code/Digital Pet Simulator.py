import random
import time
from enum import Enum
from datetime import datetime, timedelta
import pickle
import os
from typing import List, Dict, Optional

# pet.py
class Pet:
    def __init__(self, name, species):
        self.name = name
        self.species = species

    def speak(self):
        return f"{self.name} says hello!"

    def info(self):
        return f"{self.name} is a {self.species}."

class Mood(Enum):
    ECSTATIC = "😍"
    HAPPY = "😊"
    CONTENT = "🙂"
    NEUTRAL = "😐"
    ANNOYED = "😒"
    ANGRY = "😠"
    DISTRESSED = "😫"

class PetState(Enum):
    NORMAL = "Normal"
    HUNGRY = "Hungry"
    STARVING = "Starving!"
    TIRED = "Tired"
    EXHAUSTED = "Exhausted!"
    BORED = "Bored"
    DEPRESSED = "Depressed!"
    SICK = "Sick 😷"
    EVOLVED = "Evolved!"

class Pet:
    # Class variable for all pets
    TOTAL_PETS_CREATED = 0
    PET_TYPES = ["Dog", "Cat", "Dragon", "Unicorn", "Phoenix", "Robot"]
    
    def __init__(self, name: str, pet_type: str = "Dog"):
        """Initialize a new pet with default stats"""
        self.name = name
        self.pet_type = pet_type if pet_type in Pet.PET_TYPES else "Dog"
        self.hunger = 5
        self.energy = 8
        self.happiness = 7
        self.health = 10
        self.age = 0  # in days
        self.tricks: List[str] = []
        self._last_updated = datetime.now()
        self.state = PetState.NORMAL
        self.mood = Mood.HAPPY
        self._secret_name = f"Ultra {name} X"
        self._evolution_stage = 1
        self._experience = 0
        self._inventory: Dict[str, int] = {}
        
        Pet.TOTAL_PETS_CREATED += 1
        
    def __str__(self) -> str:
        return f"{self.pet_type} named {self.name} (Lv. {self._evolution_stage})"
    
    def __del__(self):
        print(f"{self.name} has gone to the digital pet heaven... 💀")
    
    @classmethod
    def get_total_pets(cls) -> int:
        """Returns total number of pets created"""
        return cls.TOTAL_PETS_CREATED
    
    @classmethod
    def create_random_pet(cls) -> 'Pet':
        """Factory method to create a random pet"""
        names = ["Spot", "Whiskers", "Ember", "Sparkle", "Zappy", "Mystic"]
        return cls(random.choice(names), random.choice(cls.PET_TYPES))
    
    def _update_stats(self):
        """Internal method to update stats based on time passed"""
        now = datetime.now()
        hours_passed = (now - self._last_updated).total_seconds() / 3600
        self._last_updated = now
        
        # Degrade stats based on time passed
        if hours_passed > 0:
            self.hunger = min(10, self.hunger + hours_passed * 0.5)
            self.energy = max(0, self.energy - hours_passed * 0.3)
            self.happiness = max(0, self.happiness - hours_passed * 0.2)
            
            # Age the pet (1 day per 24 real hours)
            self.age += hours_passed / 24
            
            # Check for evolution
            if self._experience >= self._evolution_stage * 10:
                self._evolve()
    
    def _evolve(self):
        """Evolve the pet to next stage"""
        self._evolution_stage += 1
        self._experience = 0
        self.state = PetState.EVOLVED
        print(f"✨ {self.name} has evolved to level {self._evolution_stage}! ✨")
        time.sleep(2)
        self.state = PetState.NORMAL
    
    def _update_state(self):
        """Update pet's state based on stats"""
        if self.hunger >= 8:
            self.state = PetState.STARVING
        elif self.hunger >= 5:
            self.state = PetState.HUNGRY
        elif self.energy <= 2:
            self.state = PetState.EXHAUSTED
        elif self.energy <= 4:
            self.state = PetState.TIRED
        elif self.happiness <= 2:
            self.state = PetState.DEPRESSED
        elif self.happiness <= 4:
            self.state = PetState.BORED
        else:
            self.state = PetState.NORMAL
        
        # Update mood
        if self.happiness >= 9:
            self.mood = Mood.ECSTATIC
        elif self.happiness >= 7:
            self.mood = Mood.HAPPY
        elif self.happiness >= 5:
            self.mood = Mood.CONTENT
        elif self.happiness >= 3:
            self.mood = Mood.NEUTRAL
        elif self.happiness >= 1:
            self.mood = Mood.ANNOYED
        else:
            self.mood = Mood.DISTRESSED
    
    def eat(self, food: str = "generic"):
        """Feed the pet"""
        self._update_stats()
        
        bonus = 0
        if food in self._inventory:
            bonus = 1
            self._inventory[food] -= 1
            if self._inventory[food] <= 0:
                del self._inventory[food]
        
        hunger_reduction = 3 + bonus
        self.hunger = max(0, self.hunger - hunger_reduction)
        self.happiness = min(10, self.happiness + 1 + bonus)
        self._experience += 1
        
        print(f"🍖 {self.name} ate some {food}. Hunger decreased!")
        self._update_state()
    
    def sleep(self):
        """Put the pet to sleep"""
        self._update_stats()
        
        self.energy = min(10, self.energy + 5)
        self.hunger = min(10, self.hunger + 1)
        self._experience += 2
        
        print(f"💤 {self.name} took a nap. Energy restored!")
        time.sleep(2)  # Simulate sleep time
        self._update_state()
    
    def play(self, game: str = "with you"):
        """Play with the pet"""
        self._update_stats()
        
        if self.energy < 2:
            print(f"{self.name} is too tired to play right now.")
            return
        
        self.energy = max(0, self.energy - 2)
        self.happiness = min(10, self.happiness + 2)
        self.hunger = min(10, self.hunger + 1)
        self._experience += 3
        
        print(f"⚽ {self.name} played {game}. So fun! Happiness increased!")
        self._update_state()
    
    def train(self, trick: str):
        """Teach the pet a new trick"""
        self._update_stats()
        
        if self.energy < 3:
            print(f"{self.name} is too tired to learn right now.")
            return
        
        if trick in self.tricks:
            print(f"{self.name} already knows '{trick}'!")
            return
            
        self.energy = max(0, self.energy - 3)
        self.hunger = min(10, self.hunger + 1)
        self.tricks.append(trick)
        self._experience += 5
        
        print(f"🎓 {self.name} learned a new trick: '{trick}'!")
        self._update_state()
    
    def show_tricks(self):
        """Display all learned tricks"""
        if not self.tricks:
            print(f"{self.name} hasn't learned any tricks yet.")
            return
            
        print(f"{self.name} knows these tricks:")
        for i, trick in enumerate(self.tricks, 1):
            print(f"{i}. {trick}")
    
    def get_status(self):
        """Display current pet status"""
        self._update_stats()
        self._update_state()
        
        print("\n" + "="*40)
        print(f"🐾 {self.name}'s Status ({self.mood.value}) 🐾")
        print(f"Type: {self.pet_type} | Age: {self.age:.1f} days")
        print(f"Level: {self._evolution_stage} | XP: {self._experience}/{self._evolution_stage * 10}")
        print(f"State: {self.state.value}")
        print("\nAttributes:")
        print(f"Hunger:  {'🍕' * int(self.hunger)}{' ' * (10 - int(self.hunger))} [{self.hunger:.1f}/10]")
        print(f"Energy:  {'⚡' * int(self.energy)}{' ' * (10 - int(self.energy))} [{self.energy:.1f}/10]")
        print(f"Happiness: {'❤️' * int(self.happiness)}{' ' * (10 - int(self.happiness))} [{self.happiness:.1f}/10]")
        
        if self._inventory:
            print("\nInventory:")
            for item, count in self._inventory.items():
                print(f"- {item}: {count}")
        print("="*40 + "\n")
    
    def add_to_inventory(self, item: str, quantity: int = 1):
        """Add items to pet's inventory"""
        if item in self._inventory:
            self._inventory[item] += quantity
        else:
            self._inventory[item] = quantity
        print(f"Added {quantity} {item}(s) to {self.name}'s inventory.")
    
    def save(self, filename: str):
        """Save pet to file"""
        with open(filename, 'wb') as f:
            pickle.dump(self, f)
        print(f"{self.name}'s data saved successfully!")
    
    @classmethod
    def load(cls, filename: str) -> Optional['Pet']:
        """Load pet from file"""
        if not os.path.exists(filename):
            return None
            
        with open(filename, 'rb') as f:
            pet = pickle.load(f)
        pet._last_updated = datetime.now()
        print(f"Welcome back, {pet.name}!")
        return pet
    
    def special_ability(self):
        """Unique ability based on pet type"""
        abilities = {
            "Dog": "Barks loudly to scare away negativity!",
            "Cat": "Purrs and heals itself slightly!",
            "Dragon": "Breathes fire in excitement!",
            "Unicorn": "Glows with magical sparkles!",
            "Phoenix": "Flies in a dazzling display!",
            "Robot": "Activates turbo mode for temporary boost!"
        }
        
        print(f"{self.name} uses special ability!")
        print(abilities.get(self.pet_type, "Does something cute!"))


def main():
    """Main game loop"""
    print("🌟 PyPet Master - The Ultimate Digital Pet Experience 🌟")
    print("="*60)
    
    # Try to load existing pet
    pet = Pet.load("mypet.save")
    
    if not pet:
        # Create new pet
        print("\nCreate your new digital companion!")
        name = input("Enter your pet's name: ").strip() or "Buddy"
        print("\nAvailable pet types:")
        for i, pet_type in enumerate(Pet.PET_TYPES, 1):
            print(f"{i}. {pet_type}")
        
        choice = input(f"Choose pet type (1-{len(Pet.PET_TYPES)}): ")
        try:
            pet_type = Pet.PET_TYPES[int(choice)-1]
        except (ValueError, IndexError):
            pet_type = "Dog"
        
        pet = Pet(name, pet_type)
        print(f"\nMeet your new {pet.pet_type.lower()}, {pet.name}! ❤️")
    
    # Add some starter items
    pet.add_to_inventory("treat", 3)
    pet.add_to_inventory("ball", 1)
    
    # Game loop
    while True:
        pet.get_status()
        
        print("\nWhat would you like to do?")
        print("1. Feed your pet")
        print("2. Put to sleep")
        print("3. Play with pet")
        print("4. Teach a trick")
        print("5. Show learned tricks")
        print("6. Use special ability")
        print("7. Add item to inventory")
        print("8. Save and quit")
        
        choice = input("Enter your choice (1-8): ")
        
        try:
            if choice == "1":
                food = input("What food? (or press enter for generic): ") or "generic"
                pet.eat(food)
            elif choice == "2":
                pet.sleep()
            elif choice == "3":
                game = input("What game? (or press enter): ") or "with you"
                pet.play(game)
            elif choice == "4":
                trick = input("Enter the trick to teach: ")
                if trick:
                    pet.train(trick)
            elif choice == "5":
                pet.show_tricks()
            elif choice == "6":
                pet.special_ability()
            elif choice == "7":
                item = input("Enter item name: ")
                if item:
                    quantity = input("Enter quantity (default 1): ")
                    try:
                        pet.add_to_inventory(item, int(quantity) if quantity else 1)
                    except ValueError:
                        print("Invalid quantity!")
            elif choice == "8":
                pet.save("mypet.save")
                print("Thanks for playing PyPet Master!")
                break
            else:
                print("Invalid choice. Try again.")
        except Exception as e:
            print(f"Something went wrong: {e}")
        
        input("\nPress Enter to continue...")
        print("\n"*3)  # Add some spacing


if __name__ == "__main__":
    main()